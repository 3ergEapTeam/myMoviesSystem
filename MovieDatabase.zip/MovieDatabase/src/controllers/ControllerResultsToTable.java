/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import pojos.Movie;
import pojos.FavoriteList;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class ControllerResultsToTable extends Controller {
	
	//Attributes
	private Query query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.FavoriteList> favoriteList; //Λίστα με τους τίτλους αγαπημένων λιστών
	private List<pojos.FavoriteList> favoriteList2; //Λίστα με τους τίτλους αγαπημένων λιστών
	private List<pojos.Movie> moviesList; //Λίστα με τα είδη ταινιών
				
	//Methods
    public ControllerResultsToTable()	{
		super();				
    }
    	
    //Μέθοδος για την επιστροφή των ειδών ταινιών στο combobox
    public List fillComboboxItems() {		
        try {
            et.begin();
            //Query από Entity Class FavoriteList
            query = em.createNamedQuery("FavoriteList.findAll", FavoriteList.class);
            //Αποτελέσματα αναζήτησης σε λίστα
            favoriteList = query.getResultList();
            et.commit();
		}
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return favoriteList;
    }
	
	//Μέθοδος για την επιστροφή της λίστας στην οποία ανήκει μια ταινία
	public List changeComboboxItems(String movieTitle) {		
        try {
            et.begin();
            //Query από Entity Class FavoriteList και Movie
            query = em.createQuery("SELECT f FROM FavoriteList f JOIN f.movieCollection m WHERE m.title = :title", FavoriteList.class);
			query.setParameter("title", movieTitle);
			//Αποτελέσματα αναζήτησης σε λίστα
            favoriteList2 = query.getResultList();
            et.commit();
		}
        catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return favoriteList2;
    }
	
	//Μέθοδος για την εισαγωγή ταινίας σε αγαπημένη λίστα
	public void insertMovieIntoFavList(String movieTitle, String favListName) {
		try {
            et.begin();
            //Query από Entity Class FavoriteList
			query = em.createNamedQuery("FavoriteList.findByName", FavoriteList.class);
            query.setParameter("name" , favListName);
			//Αποτελέσματα αναζήτησης σε λίστα τύπου FavoriteList 
			List<pojos.FavoriteList> currentFavLists = query.getResultList();
			//Query από Entity Class Movie
			query = em.createNamedQuery("Movie.findByTitle", Movie.class);
            query.setParameter("title" , movieTitle);
			//Αποτελέσματα αναζήτησης σε λίστα τύπου Movie 
			List<pojos.Movie> currentMovies = query.getResultList();
			
			if(currentFavLists.size() == 1 &&  currentMovies.size() == 1){
				pojos.Movie	current = currentMovies.get(0);
				pojos.FavoriteList currentFavList = currentFavLists.get(0);
				current.setFavoriteListId(currentFavList);
			}
			et.commit();
			JOptionPane.showMessageDialog(null, "Η ταινία προστέθηκε στη λίστα με επιτυχία!", "Συγχαρητήρια", JOptionPane.INFORMATION_MESSAGE);
		}
        catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
				
	}
	
	//Μέθοδος για την αφαίρεση μαις ταινίας από αγαπημένη λίστα
	public void removeMovieFromFavList(String movieTitle) {
		try {
		    et.begin();
			query = em.createNamedQuery("Movie.findByTitle", Movie.class);
            query.setParameter("title" , movieTitle);
			List<pojos.Movie> currentMovies = query.getResultList();
			if(currentMovies.get(0).getFavoriteListId() == null){
				JOptionPane.showMessageDialog(null, "Η ταινία ΔΕΝ ανήκει σε κάποια αγαπημένη λίστα! Αποτυχία αφαίρεσης!", "Σφάλμα", JOptionPane.WARNING_MESSAGE);
			}
			else {
				pojos.Movie	current = currentMovies.get(0);
				current.setFavoriteListId(null);
				et.commit();
				JOptionPane.showMessageDialog(null, "Η ταινία αφαιρέθηκε από τη λίστα με επιτυχία!", "Συγχαρητήρια", JOptionPane.INFORMATION_MESSAGE);
			}
		}
        catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
	}
		
    //Δημιουργία λίστας με τις ημερομηνίες  1/1 και 31/12 του έτους που εισάγει ο χρήστης
    public ArrayList<Date> createDateRange(String year){
        ArrayList<Date> dateRange= new ArrayList();
        Date startDate = new Date("01/01/" + year);
        Date endDate = new Date("12/31/" + year);
        dateRange.add(startDate);
        dateRange.add(endDate);
        return dateRange;
    }
	
	//Μέθοδος για την επιστροφή των ταινιών με βάση τα κριτήρια αναζήτησης
	public List<Movie> fillsearchTable(String comboSelect, String year) {
        try {
            ArrayList<Date> dateRange = createDateRange(year);
            Date startDate = dateRange.get(0);
            Date endDate = dateRange.get(1);
                 
            //Καλούμε query απο βάση για να φέρουμε τον πίνακα Movie
            query = em.createQuery("SELECT m FROM Movie m JOIN m.genreId g WHERE g.name = :name AND m.releaseDate >= :startDate AND m.releaseDate <= :endDate",Movie.class);
            query.setParameter("name", comboSelect).setParameter("startDate", startDate).setParameter("endDate", endDate);
      
            //Αποτελέσματα αναζήτησης σε λίστα
            moviesList = query.getResultList();
        } 
        catch (Exception e) {
            System.out.println(e);
            JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
        return  moviesList;
    }
}