/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import pojos.Movie;
import pojos.FavoriteList;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class ControllerResultsToTable extends Controller {
	
	//Attributes
	private Query query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.FavoriteList> favoriteList; //Λίστα με τα είδη ταινιών
	private List<pojos.Movie> moviesList; //Λίστα με τα είδη ταινιών
			
	//Methods
    public ControllerResultsToTable()	{
		super();				
    
	}
    	
	//Μέθοδος για την επιστροφή των ειδών ταινιών
    public List fillComboboxItems() {		
        try {
			et.begin();
            //Query από Entity Class FavoriteList
            query = em.createNamedQuery("FavoriteList.findAll", FavoriteList.class);
            //Αποτελέσματα αναζήτησης σε λίστα
            favoriteList = query.getResultList();
			et.commit();
		} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
		JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return favoriteList;
	}
        //Δημιουργία λίστας με τις ημερομηνίες  1/1 και 31/12 του έτους που εισάγει ο χρήστης
        public ArrayList<Date> createDateRange(String year){
            ArrayList<Date> dateRange= new ArrayList();
            String startDateString = "01/01/" + year;
            String endDateString = "12/31/" + year;
            Date startDate = new Date(startDateString);
            Date endDate = new Date(endDateString);
            dateRange.add(startDate);
            dateRange.add(endDate);
            return dateRange;
        }

	public List<Movie> fillsearchTable(String comboSelect, String year) {
		try {
                    ArrayList<Date> dateRange = createDateRange(year);
                    Date startDate = dateRange.get(0);
                    Date endDate = dateRange.get(1);
                   
                    //Καλούμε query απο βάση για να φέρουμε τον πίνακα Movie
                     query = em.createQuery("SELECT m FROM Movie m JOIN m.genreId g WHERE g.name = :name AND m.releaseDate >= :startDate AND m.releaseDate <= :endDate",Movie.class);
                     query.setParameter("name", comboSelect).setParameter("startDate", startDate).setParameter("endDate", endDate);
                    //Αποτελέσματα αναζήτησης σε λίστα
                    moviesList = query.getResultList();

        } catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
                System.out.println(e);
		JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
		return  moviesList;
	}
}