/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.List;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import pojos.Movie;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class ControllerStatisticsTable extends Controller {
	
	//Attributes
	private Query query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.Movie> topTenMoviesList; //Λίστα με τα είδη ταινιών
	private List<pojos.Movie> favListMovies; //Λίστα με τα είδη ταινιών που έχουν επιλεχτει για λίστες
		
	//Methods
    public ControllerStatisticsTable()	{
		super();				
    }
    
	//Μέθοδος για την επιστροφή των 10 καλύτερων ταινιών
    public List fillTopTenTable() {
        try {   
            //Καλούμε query απο βάση για να φέρουμε απο τον πίνακα Movie τις ταινίες με το πεδίο rating σε φθίνουσα σειρα
            query = em.createQuery("SELECT m FROM Movie m ORDER BY m.rating DESC", Movie.class);
            //Γράφουμε στο query μόνο τα 10 πρώτα αποτελέσματα
            query.setMaxResults(10);
			//Αποτελέσματα αναζήτησης σε λίστα
            topTenMoviesList = query.getResultList();
		} 
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
        return  topTenMoviesList;
    }
	
	//Μέθοδος για την επιστροφή των ταινιών σορταρισμένες ανά λίστα και βαθμολογία   
    public List fillFavListTable() {
        try {   
            //Καλούμε query απο βάση για να φέρουμε απο τον πίνακα Movie μόνο τις ταινίες που έιναι σε αγαπμένη λίστα
            query = em.createQuery("SELECT m FROM Movie m WHERE m.favoriteListId != null ORDER BY m.favoriteListId ASC, m.rating DESC", Movie.class);
			//Αποτελέσματα αναζήτησης σε λίστα
            favListMovies = query.getResultList();        
        } 
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }
        return  favListMovies;
    }
}