/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.List;
import javax.persistence.TypedQuery;
import javax.swing.JOptionPane;
import pojos.Genre;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class ControllerMovieSearch extends Controller {
	
	//Attributes
	private TypedQuery<Genre> query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.Genre> genre; //Λίστα με τα είδη ταινιών
			
	//Methods
    public ControllerMovieSearch()	{
		super();				
    
	}
    	
	//Μέθοδος για την επιστροφή των ειδών ταινιών
    public List fillComboboxItems() {		
        try {
			et.begin();
            //Query από Entity Class Genre
            query = em.createNamedQuery("Genre.findAll", Genre.class);
			//Αποτελέσματα αναζήτησης σε λίστα
            genre = query.getResultList();
			et.commit();
		} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
		JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return genre;
	}
}