/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import remoteHandlers.DBConnector;
import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
//Αφηρημένη κλάση για τη σύνδεση της εφαρμογής με τη ΒΔ 
public abstract class Controller {

    //Attributes
	//Κοινός Entity Manager για όλη τη διάρκεια εκτέλεσης της εφαρμογης
    protected EntityManager em;
	protected EntityTransaction et;
    
	//Methods
    public Controller()
    {
        if (em == null)
        {
            //Σύνδεση με τη ΒΔ μέσω Entity Factory και Entity Manager
            DBConnector.connectToDb();
            em = DBConnector.getEm();
			et = DBConnector.getEt();
        }
	
	}

}