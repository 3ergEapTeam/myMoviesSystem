/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import pojos.FavoriteList;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public final class ControllerCreateNewFavoriteMoviesList extends Controller {

	//Attributes
	private int result; //Μεταβλητή για την επιστροφή μηνυμάτων
		
	//Methods
    public ControllerCreateNewFavoriteMoviesList()	{
		super();				
    
	}
    	
	//Μέθοδος για την εισαγωγή νέας λίστας αγαπημένων ταινιών στη ΒΔ
    public int saveInDb(String txt) {		
        if (txt == null || txt.isEmpty()){
			result = 0;
			return result;
		}
		else{
			//Δημιουργία αντικειμένου FavoriteList
			FavoriteList nfl = new FavoriteList();
			nfl.setName(txt);
			try {
			et.begin();
			em.persist(nfl);
			et.commit();
			result = 1;
			return result;
			} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
				result = 0;
				return result;
			}	
		}
		
	}
	
}