/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import pojos.FavoriteList;
import java.util.List;
import javax.persistence.Query;
import javax.swing.JOptionPane;
import org.eclipse.persistence.config.HintValues;
import org.eclipse.persistence.config.QueryHints;
import pojos.Movie;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public final class ControllerManageFavoriteMoviesList extends Controller {

	//Attributes
	private int result; //Μεταβλητή για την επιστροφή μηνυμάτων
	private Query query; //Για καταχώρηση query από entity ή απλό sql
	private Query query1; //Για καταχώρηση query από entity ή απλό sql
	private Query query2; //Για καταχώρηση query από entity ή απλό sql
	private Query query3; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.FavoriteList> favoriteList; //Λίστα με τους τίτλους αγαπημένων λιστών
		
	//Methods
    public ControllerManageFavoriteMoviesList()	{
		super();				
    }
    	
	//Μέθοδος για την επιστροφή των τίτλων των αγαπημένων λιστών
    public List fillListItems() {		
        try {    
            et.begin();
			//Query από Entity Class FavoriteList με refresh για την ανανέωση
            query = em.createNamedQuery("FavoriteList.findAll", FavoriteList.class).setHint(QueryHints.REFRESH, HintValues.TRUE);
			//Αποτελέσματα αναζήτησης σε λίστα 
			favoriteList = query.getResultList();
			et.commit();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return favoriteList;
    }
	
	//Μέθοδος για τη διαγραφή αγαπημένης/-ων λίστας/-ών
	//Έλεγχος πρώτα αν η λίστα περιέχει ταινίες οι οποίες αφαιρούνται από αυτήν
	//και μετέπειτα διαγράφεται και η λίστα
	public int deleteFavListsById(int selId) {
		try {
			et.begin();
			//Query από Entity Class FavoriteList
			query1 = em.createNamedQuery("FavoriteList.findById", FavoriteList.class);
			query1.setParameter("id", selId);
			//Αποτελέσματα αναζήτησης σε λίστα τύπου FavoriteList			
			List<pojos.FavoriteList> currentFavoriteLists = query1.getResultList();
			//Query από Entity Class Movie
			query2 = em.createNamedQuery("Movie.findByFavoriteListId", Movie.class);
			query2.setParameter("favoriteListId", currentFavoriteLists.get(0));
			//Αποτελέσματα αναζήτησης σε λίστα τύπου Movie			
			List<pojos.Movie> currentMovies = query2.getResultList();
			if (!currentMovies.isEmpty()) {
				int opt = JOptionPane.showConfirmDialog(null, "Η λίστα " + currentFavoriteLists.get(0).getName() + " περιέχει ταινίες! Είστε σίγουροι για τη διαγραφή;", "Διαγραφή", JOptionPane.YES_NO_OPTION);
				if (opt == JOptionPane.YES_OPTION) {
					for (int i = 0; i < currentMovies.size(); i++) {
					pojos.Movie	current = currentMovies.get(i);
					current.setFavoriteListId(null);
					}
					//Query από Entity Class FavoriteList
					query3 = em.createQuery("DELETE FROM FavoriteList f WHERE f.id = :id");
					query3.setParameter("id", selId);
					result = query3.executeUpdate();
					et.commit();
				}
				else {
					result = 0;
					et.commit();
				}				
			}
			else {
				for (int i = 0; i < currentMovies.size(); i++) {
					pojos.Movie	current = currentMovies.get(i);
					current.setFavoriteListId(null);
				}
				//Query από Entity Class FavoriteList
				query3 = em.createQuery("DELETE FROM FavoriteList f WHERE f.id = :id");
				query3.setParameter("id", selId);
				result = query3.executeUpdate();
				et.commit();
			}
		} catch (Exception e) {
			result = 0;
		}	
		return result;
	}
}