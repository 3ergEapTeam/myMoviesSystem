/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.ArrayList;
import pojos.FavoriteList;
import java.util.List;
import javax.persistence.Query;
import javax.swing.JOptionPane;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public final class ControllerManageFavoriteMoviesList extends Controller {

	//Attributes
	private int result; //Μεταβλητή για την επιστροφή μηνυμάτων
	private Query query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.FavoriteList> favoriteList; //Λίστα με τους τίτλους λιστών αγαπημένων ταινιών
		
	//Methods
    public ControllerManageFavoriteMoviesList()	{
		super();				
    
	}
    	
	//Μέθοδος για την επιστροφή των τίτλων των αγαπημένων λιστών της ΒΔ
    public List fillListItems() {		
        try {
			et.begin();
            //Query από Entity Class FavoriteList
            query = em.createNamedQuery("FavoriteList.findAll", FavoriteList.class);
            //Αποτελέσματα αναζήτησης σε λίστα
            favoriteList = query.getResultList();
			et.commit();
		} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
		JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
        }	
		return favoriteList;
	}

	public int deleteById(ArrayList selIds) {
		try {
		et.begin();
        //Query από Entity Class FavoriteList
        query = em.createQuery("DELETE FROM FavoriteList f WHERE f.id in :ids");
		query.setParameter("ids", selIds);
		result = query.executeUpdate();
		et.commit();
		} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
		result = 0;
		}	
		return result;
	}
}