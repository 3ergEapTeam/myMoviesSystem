/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.util.List;
import javax.persistence.Query;
import pojos.FavoriteList;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public final class ControllerEditFavoriteMoviesList extends Controller {

	//Attributes
	private int result; //Μεταβλητή για την επιστροφή μηνυμάτων
	private Query query; //Για καταχώρηση query από entity ή απλό sql
		
	//Methods
    public ControllerEditFavoriteMoviesList() {
		super();				
    }
    	
	//Μέθοδος για την τροποποίηση λίστας αγαπημένων ταινιών στη ΒΔ
    public int editFavList(String txt, int selId) {		
        if (txt == null || txt.isEmpty()){
			result = 0;			
		}
		else{
			try {
				et.begin();
				//Query από Entity Class FavoriteList
				query = em.createNamedQuery("FavoriteList.findById", FavoriteList.class);
				query.setParameter("id", selId);
				//Αποτελέσματα αναζήτησης σε λίστα τύπου FavoriteList 
				List<pojos.FavoriteList> currentFavLists = query.getResultList();
				pojos.FavoriteList currentFavList = currentFavLists.get(0);
				currentFavList.setName(txt);
				et.commit();
				result = 1;
			} catch (Exception e) {
				result = 0;
			}			       
		}
		return result;
	}
}