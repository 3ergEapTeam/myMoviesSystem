/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import javax.persistence.Query;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public final class ControllerEditFavoriteMoviesList extends Controller {

	//Attributes
	private int result; //Μεταβλητή για την επιστροφή μηνυμάτων
	private Query query; //Για καταχώρηση query από entity ή απλό sql
		
	//Methods
    public ControllerEditFavoriteMoviesList()	{
		super();				
    
	}
    	
	//Μέθοδος για την εισαγωγή νέας λίστας αγαπημένων ταινιών στη ΒΔ
    public int updateInDb(String txt, int selId) {		
        if (txt == null || txt.isEmpty()){
			result = 0;
			return result;
		}
		else{
			try {
			et.begin();
            //Query από Entity Class FavoriteList
            query = em.createQuery("UPDATE FavoriteList f SET f.name = :name " + "WHERE f.id = :id");
			query.setParameter("name", txt);
			query.setParameter("id", selId);
			result = query.executeUpdate();
			et.commit();
			} catch (Exception e) { //αν δεν έπιστρέψει δεδομένα εμφάνιση μηνύματος
			result = 0;
			return result;
			}			       
		return result;		
		}
	}

}