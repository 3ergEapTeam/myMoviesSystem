/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.persistence.TypedQuery;
import pojos.Genre;
import pojos.Movie;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class ControllerAPI extends Controller {
	
	//Attributes
	public static final String urlRequest1 = "https://api.themoviedb.org/3/genre/movie/list?api_key="; //API request1
	public static final String urlRequest2 = "https://api.themoviedb.org/3/discover/movie?with_genres=28,878,10749&primary_release_date.gte=2000-01-01&api_key="; //API request2
	public static final String apiKey = "e2584aca5122bb5f220d185d89e593ef"; //API key για λήψη δεδομένων ταινιών από themoviedb.org
	private TypedQuery<Genre> query; //Για καταχώρηση query από entity ή απλό sql
	private List<pojos.Genre> gnr2store; //Για την καταχώρηση των Id των ειδών ειδών που μπορεί να ανήκει μια ταινία
		
	//Methods
    public ControllerAPI()	{
		super();				
    
	}
   	
	//Μέθοδος για το άδειασμα της ΒΔ
	public void clearDB() {
		et.begin();
		em.createQuery("DELETE FROM Movie").executeUpdate();
        em.createQuery("DELETE FROM Genre").executeUpdate();
        em.createQuery("DELETE FROM FavoriteList").executeUpdate();
		et.commit();
	}
	
	//1η κλήση API και αποθήκευση στον Πίνακα GENRE 3 συγκεκριμένα είδη
	public void createGENRE() throws IOException, Exception {
		
		//Κατασκευή URL αιτήματος
        URL url1 = new URL(urlRequest1 + apiKey);
			
		//Έναρξη σύνδεσης με τον server, αποθήκευση δεδομένων στο stream "is"          
        InputStream is1 = url1.openStream(); 
			
		//Διάβασμα stream και μετατροπή του σε χαρακτήρες
        InputStreamReader isr1 = new InputStreamReader(is1);     
		
		//Αναλύει την αρχική δομή του json που βρίσκεται στο isr, και επιστρέφει ένα JsonElement το οποίο μπορεί να είναι
        //ένα  JsonObject, JsonArray, JsonPrimitive ή ένα JsonNull
        JsonElement jElement1 = new JsonParser().parse(isr1);
			
		//Αποθήκευση σε JsonObject   
        JsonObject jsonObject1 = jElement1.getAsJsonObject(); 
            
       	//Αποθήκευση σε JsonArray
        JsonArray results1 = jsonObject1.getAsJsonArray("genres");
		
		//Αναζήτηση στο JsonArray των ειδών που είναι Action (28), Romance (10749), Sci-Fi (878)
		for (JsonElement object : results1) {
			
			//Δημιουργία JsonObject
			JsonObject object1 = object.getAsJsonObject();
						
			//Έλεγχος των ειδών ταινιών
			if (object1.get("id").getAsInt() == 28)  {
				Genre genre1 = new Genre();
				genre1.setId(object1.get("id").getAsInt());
				genre1.setName(object1.get("name").getAsString());
				et.begin();
				em.persist(genre1);
				et.commit();
			} 
			if (object1.get("id").getAsInt() == 10749 ) {
				Genre genre2 = new Genre();
				genre2.setId(object1.get("id").getAsInt());
				genre2.setName(object1.get("name").getAsString());
				et.begin();
				em.persist(genre2);
				em.getTransaction().commit();
			} 
			if (object1.get("id").getAsInt() == 878 ) {
				Genre genre3 = new Genre();
				genre3.setId(object1.get("id").getAsInt());
				genre3.setName(object1.get("name").getAsString());
				et.begin();
				em.persist(genre3);
				em.getTransaction().commit();
			} 
		}
	}
		
	//2η κλήση API και αποθήκευση στον Πίνακα MOVIE ταινιών με συγκεκριμένα κριτήρια 
	public void createMOVIE() throws IOException, Exception {
	
		//Κατασκευή URL αιτήματος
        URL url2 = new URL(urlRequest2 + apiKey);
			
		//Έναρξη σύνδεσης με τον server, αποθήκευση δεδομένων στο stream "is"          
        InputStream is2 = url2.openStream(); 
			
		//Διάβασμα stream και μετατροπή του σε χαρακτήρες
        InputStreamReader isr2 = new InputStreamReader(is2);     
		
		//Αναλύει την αρχική δομή του json που βρίσκεται στο isr, και επιστρέφει ένα JsonElement το οποίο μπορεί να είναι
        //ένα  JsonObject, JsonArray, JsonPrimitive ή ένα JsonNull
        JsonElement jElement2 = new JsonParser().parse(isr2);
			
		//Αποθήκευση σε JsonObject   
        JsonObject jsonObject2 = jElement2.getAsJsonObject(); 
            
       	//Αποθήκευση σε JsonArray
        JsonArray results2 = jsonObject2.getAsJsonArray("results");
		
		//Αναζήτηση στο JsonArray των ειδών που είναι Action (28), Romance (10749), Sci-Fi (878)
		//και έχουν κυκλοφορήσει μετά την 01/01/2000
		for (JsonElement object : results2) {
			
			//Δημιουργία JsonObject
			JsonObject object2 = object.getAsJsonObject();
			
			//Δημιουργία αντικειμένου Movie στο οποίο θα αποθηκευούτουν τα ζητούμενα πεδία
			Movie m = new Movie();
			
			//Καταχώρηση συγκεκριμένων πεδίων του json στη ΒΔ
			//Title
			m.setTitle(object2.get("title").getAsString());
			
			//Release Date
			String strrd = object2.get("release_date").getAsString();
			SimpleDateFormat sdf = new SimpleDateFormat("YYYY-MM-DD");
			Date date = sdf.parse(strrd);
			m.setReleaseDate(date);
			
			//Rating
			m.setRating(object2.get("vote_average").getAsFloat());
						
			//Overview
			m.setOverview(object2.get("overview").getAsString());
						
			//Genre IDs
			JsonArray gnrids = object2.get("genre_ids").getAsJsonArray();
			
			int i=0; //Μετρητής για την παρακάτω αναζήτηση
			//loop μέσα στα id ειδών που μπορεί να ανήκει μια ταινία και επιλογή του 1ου που θα ανήκει στα ζητούμενα είδη
			while (i<gnrids.size()) {
				if ((gnrids.get(i).getAsInt() == 28) || (gnrids.get(i).getAsInt() == 10749) || (gnrids.get(i).getAsInt() == 878)) {
					et.begin();
					query = em.createNamedQuery("Genre.findById", Genre.class);
					query.setParameter("id", gnrids.get(i).getAsInt());
					gnr2store = query.getResultList();
					m.setGenreId(gnr2store.get(0));
					et.commit();
					break; //Εφόσον βρει το επιθυμητό 1ο είδος της ταινίας σταματάει την αναζήτηση
				}
				i++; //Αύξηση κατά 1 του μετρητή για το επόμενο είδος ταινίας
			}
			et.begin();
			em.persist(m);
			et.commit();
		}
	}
	
}