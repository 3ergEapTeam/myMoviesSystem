/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package remoteHandlers;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.swing.JOptionPane;

/**
 *
 * @author Ομάδα3 ΠΛΗ24-ΘΕΣ1
 */
public class DBConnector {
	
	//Attributes
	private static final String PERSISTENCE_UNIT_NAME = "MovieDatabasePU";
    private static EntityManagerFactory emf;
    private static EntityManager em;
	private static EntityTransaction et;
    
	//Methods
	//Μέθοδος για τη σύνδεση με τη ΒΔ
    public static void connectToDb()
    {
        if (emf == null)
        {
            try 
            {
                //Δημιουργία κοινού Entity Manager για όλη τη διάρκεια εκτέλεσης της εφαρμογης
                emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
                em = emf.createEntityManager();
				et = em.getTransaction();
            } 
            catch(Exception e) 
            {
                System.out.println(e); 
                JOptionPane.showMessageDialog(null, "Αποτυχία σύνδεσης με Βάση Δεδομένων! Παρακαλώ προσπαθήστε αργότερα!", "Σφάλμα", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
	
	//Μέθοδος για την επιστροφή του Entity Manager
    public static EntityManager getEm()
    {
        return em;
    }
	
	//Μέθοδος για την επιστροφή του Entity Transaction
    public static EntityTransaction getEt()
    {
		return et;
    }
}